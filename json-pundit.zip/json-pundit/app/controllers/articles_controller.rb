class ArticlesController < ApplicationController
 
end
