# frozen_string_literal: true

class UserPolicy< ApplicationPolicy

  def update?
    true
  end

end
